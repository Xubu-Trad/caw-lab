from pathlib import Path
import hashlib, json

root = Path(__file__).resolve().parents[1]
pseudo = (root / 'enkidu.txt').read_bytes()
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(pseudo) == '4f4edfdece802b300aeab48932b115d83eb04575753bfd128a3cc47c5cc25b19'
raw = bytes.fromhex(pseudo.translate(bytes.maketrans(b'UVWXYZ', b'fedcba')).decode('ascii'))
assert sha(raw) == '03fa37cfe06c7d06d590020e9fcf8c67b4131671c10d48a6f1ef0283df8cfb22'
assert raw.count(b'\t') == 60 and raw.count(b'\n') == 155 and b'\r' not in raw
assert raw.endswith(b'\n')
candidate = raw.replace(b'\t', b' ').replace(b'\n', b'\r\n')[:-2]
assert len(candidate) == 10749
assert sha(candidate) == '5e03b441cc8dc10874f9ac956bf9c7c0574fc94e0387b3ef186661505044738b'
assert candidate.replace(b'\r\n', b'\n') + b'\n' == raw.replace(b'\t', b' ')
assert candidate == (root / 'comparison/ten-reported-hash-reconstruction.txt').read_bytes()
assert raw == (root / 'comparison/manifesto.decoded-tabs-lf.txt').read_bytes()
assert sha(candidate[:-1] + bytes([candidate[-1] ^ 1])) != sha(candidate)
print(json.dumps({'result':'PASS', 'raw_bytes':len(raw), 'candidate_bytes':len(candidate),
 'candidate_sha256':sha(candidate), 'tab_to_space':60, 'remaining_crlf':154,
 'final_newline_omitted':True, 'wording_changes':0,
 'provenance':'Reconstruction matching the hash supplied by Ten; not an independently downloaded Wayback capture.'}, indent=2))
