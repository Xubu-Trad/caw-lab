from pathlib import Path
from PIL import Image, ImageOps
import hashlib
root=Path(__file__).resolve().parents[1]
p=root/'caption/r1-tablet.png'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='889253e7fa85f5e5fd05622b8a105fd61acf83bdfdae3e600bdfedd173b2da41'
im=Image.open(p).convert('RGB');crop=im.crop((295,662,422,742));g=crop.convert('L')
checks={'crop-original-10x.png':crop.resize((1270,800),Image.Resampling.NEAREST),'crop-autocontrast-10x.png':ImageOps.autocontrast(g).resize((1270,800),Image.Resampling.NEAREST)}
for k in [8,16,24,32,48,64]:checks[f'threshold-{k}.png']=g.point(lambda x:255 if x>k else 0).resize((1270,800),Image.Resampling.NEAREST)
checks['caption-red-lsb-8x.png']=im.getchannel('R').point(lambda x:(x&1)*255).crop((295,662,422,742)).resize((1016,640),Image.Resampling.NEAREST)
for name,render in checks.items():
 saved=Image.open(root/'caption'/name)
 assert saved.mode==render.mode and saved.size==render.size and saved.tobytes()==render.tobytes(),name
print('PASS: source hash and all nine derived pixel views match. This verifies rendering, not the caption transcription.')
