# R1 missing-step reproduction package for Ten

Prepared 2026-11-11. Engineering remains paused. This package has not been sent or uploaded by this task.

## What was freshly verified

- Preserved gzip and joined-fragment hashes match their existing receipt; every one of 3,737 indexed pieces matches its size, contiguous byte range and SHA-256.
- Whitespace removal, lowercase and U–Z Atbash conversion of that preserved stream reconstruct the exact locally retained APE. The audio here is therefore a verified reconstruction, not claimed to be a fresh gateway download.
- Standard-library UnixFS/DAG-PB replay computes **QmddMfUi8AgsRyqa8MdsWqoCLYmV6kVJ4PYm6uo3iQ7WCV** from these exact bytes. The empty-file vector passes and a one-bit mutation changes the CID. See receipts/cid/.
- Fresh FFmpeg decoding and the public extraction script produce enkidu.txt, byte-identical to both preserved public Enkidu copies. The decoder reads the declared filename/length before checking the output hash.
- Atbash UVWXYZ -> fedcba, hex decoding and replacing exactly 60 tabs with single spaces reproduce the preserved English manifesto. Do not reverse the bytes or normalize all whitespace.

## Input identities

| File | Bytes | SHA-256 |
|---|---:|---|
| canonical.ape | 8968236 | 57674107710cdac58fe68b30cb3c05e3334ece55bc0d71deba84ccd2a8fb3575 |
| enkidu.txt (extracted, not a reconstruction from the manifesto) | 21192 | 4f4edfdece802b300aeab48932b115d83eb04575753bfd128a3cc47c5cc25b19 |
| Decoded PCM samples (WAV headers excluded) | 25964464 | 9a50dfecbbe8612b6470f804e6a752d2d98ad43c2daae126fd80fc4bf094086d |
| Manifesto before tab replacement | 10596 | 03fa37cfe06c7d06d590020e9fcf8c67b4131671c10d48a6f1ef0283df8cfb22 |
| Preserved English manifesto | 10596 | 836c98641fd1222156d49c68d210d9860319b323f890b5af82860ac14aba366c |

## Replay from the extracted package root

Use Python 3, FFmpeg and the Python cryptography package. See receipts/versions.txt for the actual environment. Inspect scripts before running. No archived executable or DeepSound binary is included or executed. Preserve exact bytes; disable automatic text line-ending conversion.

```sh
sha256sum -c SHA256SUMS.txt
python3 scripts/reproduce_r1_cid.py canonical.ape --out-dir my-cid-replay
ffmpeg -v error -nostdin -i canonical.ape -c:a pcm_s16le -n my-canonical.wav
python3 scripts/reproduce_ape_to_enkidu.py canonical.ape my-canonical.wav --output my-enkidu.txt --receipt my-extraction.json
cmp my-enkidu.txt enkidu.txt
python3 scripts/reproduce_enkidu.py
```

Use new output names/directories. The supplied extraction uses DeepSound normal-quality LSB decoding, password `enkidu`, and AES-256-ECB with the ASCII password zero-padded to 32 bytes. Ten may additionally replay with an independently obtained DeepSound implementation; that GUI/tool replay was not performed here. WAV container headers may differ by FFmpeg version; the invariant is the decoded PCM hash, format and frame count.

## Provenance boundaries

Pinned public scripts and comparison files: https://github.com/Xubu-Trad/caw-lab/tree/b4501452e711933a99ff17bb23f49038d82fe584. Local preserved source receipt: R1-20260905-JNWW-001, supplied JNWW fragments assembled in filename order. The raw fragment archive is not required for the audio/CID replay and is not included in this minimal package; receipts describe the verified local assembly. Its receipt date and filesystem timestamps do not prove possession in 2022.

The CID match establishes content identity under the recorded importer settings (262144-byte chunks, DAG-PB non-raw leaves, balanced layout, present empty legacy link names, no directory wrapper/mode/mtime). The CID is not simply the SHA-256 of the raw file. This bridges the book-derived address to these bytes without live retrieval, assuming the separately reproduced book-cipher CID. Historical retrieval/custody, author identity, and continuous IPFS availability remain unproved.

This package does not verify the disputed caption lines, prove an additional riddle layer, or prove that the riddles are terminally solved. The v2 comparison reconstructs Ten's reported 10,749-byte SHA-256 exactly using only tab replacement, CRLF line endings and omission of the final newline. See comparison/COMPARISON.md for every difference and the provenance boundary; this is not a fresh Wayback download.

## What to report back

Record input hashes, tools/versions, computed CID, the extracted filename/length/hash, and any difference. Distinguish extraction/CID reproduction from historical custody evidence. Preserve failures; do not edit inputs to make the hashes match.

## Version 2 comparison update

The original package remains unchanged. Run `python3 scripts/compare_ten_manifesto.py` for the additional exact-hash comparison. No wording changes were found relative to Ten's reported digest. See comparison/COMPARISON.md and receipts/manifesto-comparison.json.

## Version 3 caption review

The original tablet PNG and nine reproducible pixel views are included in caption/. Lines 4–6 remain UNVERIFIED: direct inspection did not support a reliable exact transcription. See caption/CAPTION_REVIEW.md for the negative result and remaining boundaries. Run `python3 scripts/verify_caption_views.py` with Pillow installed. Prior packages remain unchanged.
